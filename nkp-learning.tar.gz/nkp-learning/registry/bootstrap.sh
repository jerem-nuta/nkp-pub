#!/usr/bin/env bash
set -euxo pipefail
MARKER=/var/lib/harbor-bootstrap.done
[ -f "$MARKER" ] && exit 0

# --- repo PUBLIC du bundle solo (clone HTTPS anonyme, pas de deploy key) ---
BUNDLE_GIT="${BUNDLE_GIT:-https://github.com/jerem-nuta/nkp-pub.git}"
BUNDLE_STAGE="/opt/harbor/bundle/nkp-learning"

# docker
dnf -y install dnf-plugins-core git curl tar openssl 2>/dev/null || true
cat > /etc/yum.repos.d/docker-ce.repo <<'REPO'
[docker-ce-stable]
name=Docker CE Stable
baseurl=https://download.docker.com/linux/rhel/10/$basearch/stable
enabled=1
gpgcheck=1
gpgkey=https://download.docker.com/linux/rhel/gpg
REPO
dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin 2>/dev/null || true
systemctl enable --now docker 2>/dev/null || true
for i in $(seq 1 20); do docker info >/dev/null 2>&1 && break || sleep 3; done

# --- récupérer le bundle: clone du repo public ---
mkdir -p /opt/harbor/bundle
if [ ! -d "$BUNDLE_STAGE" ]; then
  rm -rf /opt/harbor/repo
  git clone --depth 1 "$BUNDLE_GIT" /opt/harbor/repo
  # le dossier nkp-learning/ peut être à la racine du repo, ou le repo EST le bundle
  if [ -d /opt/harbor/repo/nkp-learning ]; then
    cp -rf /opt/harbor/repo/nkp-learning "$BUNDLE_STAGE"
  else
    cp -rf /opt/harbor/repo "$BUNDLE_STAGE"
  fi
fi
[ -d "$BUNDLE_STAGE" ] || { echo "FATAL: bundle introuvable après clone de $BUNDLE_GIT" >&2; exit 1; }
[ -f "$BUNDLE_STAGE/registry/install-harbor.sh" ] || { echo "FATAL: install-harbor.sh absent du bundle" >&2; ls -R "$BUNDLE_STAGE" >&2; exit 1; }

chmod +x "$BUNDLE_STAGE/registry/install-harbor.sh"
"$BUNDLE_STAGE/registry/install-harbor.sh"
touch "$MARKER"
