#!/usr/bin/env bash
# ============================================================================
#  install-harbor.sh — VERSION SOLO (mono-utilisateur, tout local)
#  Harbor + sources NKP (file server) + downloader. Cert auto-signé au boot.
#  UN seul compte local (basic-auth) partout. Pas d'AD/LDAP/PKI/portail.
# ============================================================================
set -euo pipefail
log(){ echo "===== $* ====="; }

# --- config (surchargée par /opt/harbor/nkp-admin.env si présent) ---
ADMIN_USER="admin"
ADMIN_PASSWORD="Harbor12345"
HARBOR_VERSION="v2.15.1"
# Identite de la VM: le NOM et l'IP viennent de Prism (preserve_hostname + DHCP/statique).
# On privilegie l'IP pour les URL (pas de dependance DNS), le nom reste dans le cert.
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
FQDN="$(hostname -f 2>/dev/null || hostname)"
[ -n "$FQDN" ] || FQDN="nkp-learning.local"
# HOST_URL = ce qui apparait dans les liens et dans l'URL du registre
HOST_URL="${IP:-$FQDN}"
[ -f /opt/harbor/nkp-admin.env ] && . /opt/harbor/nkp-admin.env
# rétro-compat noms de variables
ADMIN_USER="${LAB_ADMIN_USER:-${ADMIN_USER}}"
ADMIN_PASSWORD="${LAB_ADMIN_PASSWORD:-${ADMIN_PASSWORD}}"

BUNDLE_STAGE="/opt/harbor/bundle/nkp-learning"
CERT_DIR="/opt/harbor/certs"
DATA_DIR="/data/nkp-sources"

log "[1/7] cert auto-signé (openssl, SAN = ${FQDN} + hostname + IP)"
mkdir -p "$CERT_DIR"
if [ ! -s "$CERT_DIR/server.crt" ] || [ ! -s "$CERT_DIR/server.key" ]; then
  HN="$(hostname -s 2>/dev/null || echo nkp-learning)"
  SAN="DNS:${FQDN},DNS:${HN}"
  [ -n "$IP" ] && SAN="${SAN},IP:${IP}"
  openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout "$CERT_DIR/server.key" -out "$CERT_DIR/server.crt" \
    -days 3650 -subj "/CN=${FQDN}" -addext "subjectAltName=${SAN}"
  chmod 600 "$CERT_DIR/server.key"; chmod 644 "$CERT_DIR/server.crt"
  echo "cert auto-signé généré (SAN=${SAN})"
else
  echo "cert déjà présent, on garde"
fi

log "[2/7] paquets (docker, nginx, apache-tools)"
dnf -y install nginx httpd-tools jq curl tar 2>/dev/null || true
# docker déjà installé par le bootstrap; on s'assure qu'il tourne
systemctl enable --now docker 2>/dev/null || true

log "[3/7] file server (sources NKP) + basic-auth"
mkdir -p "$DATA_DIR"
htpasswd -bc /etc/nginx/nkp-files.htpasswd "$ADMIN_USER" "$ADMIN_PASSWORD"
cp "${BUNDLE_STAGE}/registry/nkp-sources.conf" /etc/nginx/conf.d/nkp-sources.conf
# le port 8080 sur SELinux
command -v semanage >/dev/null 2>&1 && semanage port -a -t http_port_t -p tcp 8080 2>/dev/null || true
nginx -t && systemctl enable --now nginx && systemctl reload nginx

log "[4/7] Harbor (registre) — cert auto-signé, mot de passe local"
if [ ! -d /opt/harbor/harbor ]; then
  cd /opt/harbor
  curl -fsSL "https://github.com/goharbor/harbor/releases/download/${HARBOR_VERSION}/harbor-offline-installer-${HARBOR_VERSION}.tgz" -o harbor.tgz
  tar xzf harbor.tgz && rm -f harbor.tgz
fi
# harbor.yml minimal
cat > /opt/harbor/harbor/harbor.yml << YML
hostname: ${HOST_URL}
http:
  port: 80
https:
  port: 443
  certificate: ${CERT_DIR}/server.crt
  private_key: ${CERT_DIR}/server.key
harbor_admin_password: ${ADMIN_PASSWORD}
database:
  password: root123
  max_idle_conns: 100
  max_open_conns: 900
data_volume: /data
trivy:
  ignore_unfixed: false
  skip_update: false
  offline_scan: false
  security_check: vuln
jobservice:
  max_job_workers: 10
  job_loggers: [STD_OUTPUT, FILE]
  logger_sweeper_duration: 1
log:
  level: info
  local:
    rotate_count: 50
    rotate_size: 200M
    location: /var/log/harbor
_version: 2.15.0
YML
cd /opt/harbor/harbor
if ! docker ps --format '{{.Names}}' | grep -q harbor-core; then
  ./prepare && ./install.sh
fi

log "[5/7] attendre Harbor"
for i in $(seq 1 40); do
  code="$(curl -k -s -o /dev/null -w '%{http_code}' "https://${HOST_URL}/api/v2.0/health" 2>/dev/null || echo 000)"
  [ "$code" = "200" ] && { echo "Harbor up"; break; }
  sleep 5
done

log "[6/7] downloader (backend HTTPS loopback:8445, même user local)"
mkdir -p /opt/harbor/downloader
cp "${BUNDLE_STAGE}/registry-web/downloader-backend/"{Dockerfile,app.py,page.html,docker-compose.yml} /opt/harbor/downloader/
cd /opt/harbor/downloader
DL_USER="${ADMIN_USER}" DL_PASS="${ADMIN_PASSWORD}" docker compose up -d --build
# health-check
for i in $(seq 1 20); do
  code="$(curl -k -s -o /dev/null -w '%{http_code}' "https://127.0.0.1:8445/" 2>/dev/null || echo 000)"
  { [ "$code" = "200" ] || [ "$code" = "401" ]; } && { echo "downloader OK (:8445)"; break; }
  sleep 3
done

log "[7/7] terminé"
echo "  Registre Harbor : https://${HOST_URL}/   (admin / ${ADMIN_PASSWORD})"
echo "  Sources NKP     : https://${HOST_URL}:8080/   (${ADMIN_USER} / ${ADMIN_PASSWORD})"
echo "  Downloader      : https://${HOST_URL}:8080/downloader/"
echo "  (nom DNS: ${FQDN} — utilisable si la resolution fonctionne)"
echo "  docker login ${HOST_URL} -u ${ADMIN_USER}"
echo "  Cert auto-signé (à accepter dans le navigateur)."
touch /var/lib/harbor-install.done
