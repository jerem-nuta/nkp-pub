#!/usr/bin/env bash
# ============================================================================
#  install-harbor.sh — VERSION SOLO (mono-utilisateur, tout local)
#  Harbor + sources NKP (file server) + downloader. Cert auto-signé au boot.
#  UN seul compte local (basic-auth) partout. Pas d'AD/LDAP/PKI/portail.
# ============================================================================
set -euo pipefail
log(){ echo "===== $* ====="; }

# --- config (surchargée par /opt/harbor/nkp-admin.env si présent) ---
ADMIN_USER="admin"
ADMIN_PASSWORD="Harbor12345"
HARBOR_VERSION="v2.15.1"
# Identite de la VM: le NOM et l'IP viennent de Prism (preserve_hostname + DHCP/statique).
# On privilegie l'IP pour les URL (pas de dependance DNS), le nom reste dans le cert.
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
FQDN="$(hostname -f 2>/dev/null || hostname)"
[ -n "$FQDN" ] || FQDN="nkp-learning.local"
# HOST_URL = ce qui apparait dans les liens et dans l'URL du registre
HOST_URL="${IP:-$FQDN}"
[ -f /opt/harbor/nkp-admin.env ] && . /opt/harbor/nkp-admin.env
# rétro-compat noms de variables
ADMIN_USER="${LAB_ADMIN_USER:-${ADMIN_USER}}"
ADMIN_PASSWORD="${LAB_ADMIN_PASSWORD:-${ADMIN_PASSWORD}}"

BUNDLE_STAGE="/opt/harbor/bundle/nkp-learning"
CERT_DIR="/opt/harbor/certs"
DATA_DIR="/data/nkp-sources"

log "[1/8] cert auto-signé (openssl, SAN = ${FQDN} + hostname + IP)"
mkdir -p "$CERT_DIR"
if [ ! -s "$CERT_DIR/server.crt" ] || [ ! -s "$CERT_DIR/server.key" ]; then
  HN="$(hostname -s 2>/dev/null || echo nkp-learning)"
  SAN="DNS:${FQDN},DNS:${HN}"
  [ -n "$IP" ] && SAN="${SAN},IP:${IP}"
  openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout "$CERT_DIR/server.key" -out "$CERT_DIR/server.crt" \
    -days 3650 -subj "/CN=${FQDN}" -addext "subjectAltName=${SAN}"
  chmod 600 "$CERT_DIR/server.key"; chmod 644 "$CERT_DIR/server.crt"
  echo "cert auto-signé généré (SAN=${SAN})"
else
  echo "cert déjà présent, on garde"
fi

log "[2/8] paquets (docker, nginx, apache-tools)"
dnf -y install nginx httpd-tools jq curl tar 2>/dev/null || true
# docker déjà installé par le bootstrap; on s'assure qu'il tourne
systemctl enable --now docker 2>/dev/null || true

log "[3/8] file server (sources NKP) + basic-auth"
# STOCKAGE 100% LOCAL: pas de NFS, pas de partage reseau.
# /data porte a la fois les images Harbor et les bundles NKP -> on verifie la place.
mkdir -p "$DATA_DIR"
_avail_gb="$(df -BG --output=avail /data 2>/dev/null | tail -1 | tr -dc '0-9')"
if [ -n "${_avail_gb}" ]; then
  echo "espace libre sur /data (disque local): ${_avail_gb} Go"
  if [ "${_avail_gb}" -lt 60 ]; then
    echo "WARN: moins de 60 Go libres. Harbor + un bundle NKP tiennent difficilement." >&2
    echo "      Prevoir un disque d'au moins 150 Go pour plusieurs versions NKP." >&2
  fi
fi
htpasswd -bc /etc/nginx/nkp-files.htpasswd "$ADMIN_USER" "$ADMIN_PASSWORD"
cp "${BUNDLE_STAGE}/registry/nkp-sources.conf" /etc/nginx/conf.d/nkp-sources.conf
# le port 8080 sur SELinux
command -v semanage >/dev/null 2>&1 && semanage port -a -t http_port_t -p tcp 8080 2>/dev/null || true
nginx -t && systemctl enable --now nginx && systemctl reload nginx

log "[4/8] Harbor (registre) — cert auto-signé, mot de passe local"
if [ ! -d /opt/harbor/harbor ]; then
  cd /opt/harbor
  curl -fsSL "https://github.com/goharbor/harbor/releases/download/${HARBOR_VERSION}/harbor-offline-installer-${HARBOR_VERSION}.tgz" -o harbor.tgz
  tar xzf harbor.tgz && rm -f harbor.tgz
fi
# harbor.yml minimal
cat > /opt/harbor/harbor/harbor.yml << YML
hostname: ${HOST_URL}
http:
  port: 80
https:
  port: 443
  certificate: ${CERT_DIR}/server.crt
  private_key: ${CERT_DIR}/server.key
harbor_admin_password: ${ADMIN_PASSWORD}
database:
  password: root123
  max_idle_conns: 100
  max_open_conns: 900
data_volume: /data
trivy:
  ignore_unfixed: false
  skip_update: false
  offline_scan: false
  security_check: vuln
jobservice:
  max_job_workers: 10
  job_loggers: [STD_OUTPUT, FILE]
  logger_sweeper_duration: 1
log:
  level: info
  local:
    rotate_count: 50
    rotate_size: 200M
    location: /var/log/harbor
_version: 2.15.0
YML
cd /opt/harbor/harbor
if ! docker ps --format '{{.Names}}' | grep -q harbor-core; then
  ./prepare && ./install.sh
fi

log "[5/8] attendre Harbor"
for i in $(seq 1 40); do
  code="$(curl -k -s -o /dev/null -w '%{http_code}' "https://${HOST_URL}/api/v2.0/health" 2>/dev/null || echo 000)"
  [ "$code" = "200" ] && { echo "Harbor up"; break; }
  sleep 5
done

log "[6/8] cache Docker Hub (optionnel)"
# Si /opt/harbor/dockerhub.env fournit un compte, on cree dans Harbor:
#   - un "registry endpoint" vers Docker Hub (authentifie = limites de pull bien plus hautes)
#   - un projet PROXY CACHE "dockerhub" qui sert de miroir local
# Sans identifiants: on saute (Harbor reste utilisable, mais pulls anonymes limites).
DH_USER=""; DH_TOKEN=""
[ -f /opt/harbor/dockerhub.env ] && . /opt/harbor/dockerhub.env
DH_USER="${DOCKERHUB_USER:-$DH_USER}"; DH_TOKEN="${DOCKERHUB_TOKEN:-$DH_TOKEN}"
case "$DH_TOKEN" in REPLACE_WITH_*|"") DH_TOKEN="";; esac
if [ -n "$DH_USER" ] && [ -n "$DH_TOKEN" ]; then
  HAPI="https://${HOST_URL}/api/v2.0"
  # 1) endpoint vers Docker Hub (idempotent: on ignore le 409 "deja existant")
  code="$(curl -k -s -o /tmp/dh1.json -w '%{http_code}' -u "admin:${ADMIN_PASSWORD}" \
    -X POST "${HAPI}/registries" -H 'Content-Type: application/json' -d @- <<JSON || true
{"name":"dockerhub","type":"docker-hub","url":"https://hub.docker.com",
 "credential":{"type":"basic","access_key":"${DH_USER}","access_secret":"${DH_TOKEN}"},
 "insecure":false}
JSON
)"
  echo "  endpoint dockerhub -> HTTP ${code}"
  # 2) recuperer son id
  DH_ID="$(curl -k -s -u "admin:${ADMIN_PASSWORD}" "${HAPI}/registries?q=name%3Ddockerhub" \
    | grep -oE '"id":[0-9]+' | head -1 | cut -d: -f2 || true)"
  if [ -n "$DH_ID" ]; then
    # 3) projet proxy cache "dockerhub"
    code="$(curl -k -s -o /tmp/dh2.json -w '%{http_code}' -u "admin:${ADMIN_PASSWORD}" \
      -X POST "${HAPI}/projects" -H 'Content-Type: application/json' \
      -d "{\"project_name\":\"dockerhub\",\"public\":true,\"registry_id\":${DH_ID}}" || true)"
    echo "  projet proxy-cache dockerhub -> HTTP ${code}"
    echo "  usage: docker pull ${HOST_URL}/dockerhub/library/alpine:3.20"
  else
    echo "  WARN: id de l'endpoint dockerhub introuvable, cache non cree" >&2
  fi
else
  echo "  pas d'identifiants Docker Hub -> cache non configure (pulls anonymes limites)"
  echo "  pour l'activer: renseigner DOCKERHUB_USER/DOCKERHUB_TOKEN dans le cloud-init"
fi

log "[7/8] downloader (backend HTTPS loopback:8445, même user local)"
mkdir -p /opt/harbor/downloader
cp "${BUNDLE_STAGE}/registry-web/downloader-backend/"{Dockerfile,app.py,page.html,docker-compose.yml} /opt/harbor/downloader/
cd /opt/harbor/downloader
DL_USER="${ADMIN_USER}" DL_PASS="${ADMIN_PASSWORD}" docker compose up -d --build
# health-check
for i in $(seq 1 20); do
  code="$(curl -k -s -o /dev/null -w '%{http_code}' "https://127.0.0.1:8445/" 2>/dev/null || echo 000)"
  { [ "$code" = "200" ] || [ "$code" = "401" ]; } && { echo "downloader OK (:8445)"; break; }
  sleep 3
done

log "[8/8] terminé"
echo "  Registre Harbor : https://${HOST_URL}/   (admin / ${ADMIN_PASSWORD})"
echo "  Sources NKP     : https://${HOST_URL}:8080/   (${ADMIN_USER} / ${ADMIN_PASSWORD})"
echo "  Downloader      : https://${HOST_URL}:8080/downloader/"
echo "  (nom DNS: ${FQDN} — utilisable si la resolution fonctionne)"
echo "  docker login ${HOST_URL} -u ${ADMIN_USER}"
[ -n "${DH_USER:-}" ] && [ -n "${DH_TOKEN:-}" ] && \
  echo "  Cache Docker Hub : ${HOST_URL}/dockerhub/<image>  (ex: library/alpine:3.20)"
echo "  Cert auto-signé (à accepter dans le navigateur)."
touch /var/lib/harbor-install.done
