# certs/ — place the PEM content of each file here

install.sh validates ALL of these on the fly before deploying:

| File              | What it is                                                        |
|-------------------|-------------------------------------------------------------------|
| `ca-chain.crt`    | Root + Issuing CA chain (SUBCA + ROOT), PEM, 2 certs. Trusts Harbor + PC. |
| `pc-ca.crt`       | PC CA chain. Same PKI here, so usually identical to ca-chain.crt.  |
| `nkp-ingress.crt` | Kommander dashboard cert. SAN MUST include `<NKP_FQDN>`. |
| `nkp-ingress.key` | Private key matching nkp-ingress.crt (modulus must match).        |
| `nkp-ssh.pub`     | SSH public key placed on all nodes.                               |

Generate the SSH key (run inside this certs/ folder):
    ssh-keygen -t ed25519 -f ./nkp-ssh -N "" -C "nkp-nodes"
    # keep the private key ./nkp-ssh safe — it's how you SSH to the nodes

Verify a chain is complete (must print "Verify return code: 0 (ok)"):
    openssl s_client -connect <PRISM_CENTRAL>:9440 -CAfile pc-ca.crt </dev/null 2>/dev/null | grep "Verify return code"

Chain order: leaf-most first, root last (SUBCA then ROOT).
