#!/usr/bin/env bash
############################################################
# NKP all-in-one installer (per-version, self-contained folder)
#   cd v2.17.1 ; ./install.sh
# Sources ./nkp.env, validates ./certs/*, then runs nkp create cluster.
############################################################
set -euo pipefail

# ---- locate this folder, source the env ----
CONFIG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$CONFIG_DIR"
[ -f "$CONFIG_DIR/nkp.env" ] || { echo "ERROR: nkp.env not found in $CONFIG_DIR"; exit 1; }
set -a; source "$CONFIG_DIR/nkp.env"; set +a

# resolve cert paths relative to this folder
PC_CA_CERT="$CONFIG_DIR/$PC_CA_CERT_FILE"
REGISTRY_CACERT="$CONFIG_DIR/$REGISTRY_CACERT_FILE"
INGRESS_CA="$CONFIG_DIR/$INGRESS_CA_FILE"
INGRESS_CERT="$CONFIG_DIR/$INGRESS_CERT_FILE"
INGRESS_KEY="$CONFIG_DIR/$INGRESS_KEY_FILE"
SSH_PUBLIC_KEY_FILE="$CONFIG_DIR/$SSH_PUBLIC_KEY_FILE_REL"

ok(){ printf "  \033[32m✓\033[0m %s\n" "$1"; }
no(){ printf "  \033[31m✗\033[0m %s\n" "$1"; FAIL=1; }
hd(){ printf "\n\033[1m── %s ──\033[0m\n" "$1"; }
FAIL=0

echo "NKP ${NKP_VERSION} deploy — config: $CONFIG_DIR"
echo "  cluster=${CLUSTER_NAME}  project=${PROJECT_NAME}  mirror=${REGISTRY_MIRROR_URL}"

# ====================================================================
hd "1. cert files present"
for f in "$PC_CA_CERT" "$REGISTRY_CACERT" "$INGRESS_CERT" "$INGRESS_KEY" "$SSH_PUBLIC_KEY_FILE"; do
  [ -s "$f" ] && ok "$(basename "$f") present" || no "MISSING/empty: $f"
done
[ "$FAIL" = 1 ] && { echo; echo "Place the required files in $CONFIG_DIR/certs/ then re-run."; exit 1; }

# ====================================================================
hd "2. validate PC CA chain (must be complete: leaf verifies to root)"
PC_HOST="${NUTANIX_ENDPOINT#https://}"
# count certs in the bundle
N=$(grep -c "BEGIN CERTIFICATE" "$PC_CA_CERT" || true)
[ "$N" -ge 1 ] && ok "PC CA bundle has $N cert(s)" || no "PC CA bundle empty"
# live verify against PC using the bundle as the trust anchor
VR="$(openssl s_client -connect "${PC_HOST}:${NUTANIX_PORT}" -CAfile "$PC_CA_CERT" </dev/null 2>/dev/null | grep 'Verify return code' || true)"
echo "    $VR"
echo "$VR" | grep -q "0 (ok)" && ok "PC cert verifies against bundle" || no "PC cert does NOT verify with $PC_CA_CERT_FILE (incomplete chain?)"

# ====================================================================
hd "3. install PC CA into OS trust (preflight uses the system store)"
# the in-cluster + bastion preflight path consults the OS trust store
if ! openssl s_client -connect "${PC_HOST}:${NUTANIX_PORT}" </dev/null 2>/dev/null | grep -q "Verify return code: 0 (ok)"; then
  echo "    PC not yet trusted by OS store — installing $PC_CA_CERT_FILE"
  sudo cp "$PC_CA_CERT" /etc/pki/ca-trust/source/anchors/<LAB>-pc-ca.crt
  sudo update-ca-trust extract
  openssl s_client -connect "${PC_HOST}:${NUTANIX_PORT}" </dev/null 2>/dev/null | grep -q "Verify return code: 0 (ok)" \
    && ok "OS now trusts PC" || no "OS still does not trust PC after update-ca-trust"
else
  ok "OS already trusts PC"
fi

# ====================================================================
hd "4. validate ingress cert (SAN covers CLUSTER_HOSTNAME, key matches)"
if openssl x509 -in "$INGRESS_CERT" -noout -ext subjectAltName 2>/dev/null | grep -q "$CLUSTER_HOSTNAME"; then
  ok "ingress SAN includes $CLUSTER_HOSTNAME"
else
  no "ingress SAN does NOT include $CLUSTER_HOSTNAME"
  echo "      SAN: $(openssl x509 -in "$INGRESS_CERT" -noout -ext subjectAltName 2>/dev/null | tail -1 | tr -s ' ')"
fi
CM=$(openssl x509 -noout -modulus -in "$INGRESS_CERT" 2>/dev/null | openssl md5)
KM=$(openssl rsa  -noout -modulus -in "$INGRESS_KEY"  2>/dev/null | openssl md5)
[ "$CM" = "$KM" ] && ok "ingress cert+key modulus match" || no "ingress cert/key MISMATCH"

# ====================================================================
hd "5. validate registry CA trust + reachability + project"
if curl -fsS --cacert "$REGISTRY_CACERT" -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "$REGISTRY_URL/api/v2.0/health" >/dev/null 2>&1; then
  ok "Harbor health OK (TLS verified)"
else
  curl -fsSk -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "$REGISTRY_URL/api/v2.0/health" >/dev/null 2>&1 \
    && no "Harbor reachable but CA does NOT verify (check ca-chain.crt)" \
    || no "Harbor NOT reachable at $REGISTRY_URL"
fi
curl -fsSk -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "$REGISTRY_URL/api/v2.0/projects?name=$REGISTRY_MIRROR_PROJECT" 2>/dev/null \
  | grep -q "\"name\":\"$REGISTRY_MIRROR_PROJECT\"" \
  && ok "mirror project '$REGISTRY_MIRROR_PROJECT' exists" \
  || no "mirror project '$REGISTRY_MIRROR_PROJECT' missing — push bundles first"

# ====================================================================
hd "6. addressing sanity (LB range must not overlap nodes/VIP)"
ip2n(){ IFS=.; set -- $1; echo $(( ($1<<24)+($2<<16)+($3<<8)+$4 )); }
lo="${LB_IP_RANGE%-*}"; hi="${LB_IP_RANGE#*-}"
cn=$(ip2n "$CONTROL_PLANE_ENDPOINT_IP"); ln=$(ip2n "$lo"); hn=$(ip2n "$hi")
[ "$cn" -ge "$ln" ] && [ "$cn" -le "$hn" ] && no "API VIP $CONTROL_PLANE_ENDPOINT_IP is INSIDE LB range" || ok "API VIP outside LB range"
# warn if any LB IP currently answers ping (likely a node already holds it)
for n in $(seq "$((ln & 255))" "$((hn & 255))"); do
  ipx="<SUBNET>.$n"
  ping -c1 -W1 "$ipx" >/dev/null 2>&1 && echo "    \033[33m! $ipx in LB range is already in use (node? other?)\033[0m"
done

# ====================================================================
hd "7. bastion overlay MTU (Flow VPC needs 1442)"
mtu=$(ip link show docker0 2>/dev/null | grep -o 'mtu [0-9]*' | awk '{print $2}' || true)
[ "$mtu" = "1442" ] && ok "docker0 MTU 1442" || echo "    ! docker0 MTU=${mtu:-none} (set 1442 before bootstrap, or kind may hang)"

# ====================================================================
[ "$FAIL" = 1 ] && { echo; echo -e "\033[31mVALIDATION FAILED — fix the ✗ items above. Not deploying.\033[0m"; exit 1; }
echo; echo -e "\033[32mAll validations passed.\033[0m"

# ---- bootstrap image ----
hd "8. load bootstrap image"
sudo docker load -i "$BOOTSTRAP_IMAGE" 2>/dev/null || docker load -i "$BOOTSTRAP_IMAGE"

# ---- build args ----
PC_ENDPOINT="${NUTANIX_ENDPOINT}:${NUTANIX_PORT}"
PC_CA_B64="$(base64 -w0 "$PC_CA_CERT")"

SKIP_FLAG=()
[ "${SKIP_NUTANIX_CRED_PREFLIGHT:-false}" = "true" ] && SKIP_FLAG=(--skip-preflight-checks=NutanixCredentials)

hd "9. nkp create cluster"
set -x
nkp create cluster nutanix \
  --cluster-name "${CLUSTER_NAME}" \
  --cluster-hostname "${CLUSTER_HOSTNAME}" \
  --endpoint "${PC_ENDPOINT}" \
  --additional-trust-bundle "${PC_CA_B64}" \
  --control-plane-endpoint-ip "${CONTROL_PLANE_ENDPOINT_IP}" \
  --control-plane-vm-image "${NODE_IMAGE_NAME}" \
  --control-plane-prism-element-cluster "${PRISM_ELEMENT_CLUSTER}" \
  --control-plane-subnets "${SUBNET_NAME}" \
  --control-plane-pc-project "${PROJECT_NAME}" \
  --control-plane-replicas "${CONTROL_PLANE_REPLICAS}" \
  --control-plane-vcpus "${CONTROL_PLANE_VCPUS}" \
  --control-plane-cores-per-vcpu "${CONTROL_PLANE_CORES_PER_VCPU}" \
  --control-plane-memory "${CONTROL_PLANE_MEMORY_GIB}" \
  --worker-vm-image "${NODE_IMAGE_NAME}" \
  --worker-prism-element-cluster "${PRISM_ELEMENT_CLUSTER}" \
  --worker-subnets "${SUBNET_NAME}" \
  --worker-pc-project "${PROJECT_NAME}" \
  --worker-replicas "${WORKER_REPLICAS}" \
  --worker-vcpus "${WORKER_VCPUS}" \
  --worker-cores-per-vcpu "${WORKER_CORES_PER_VCPU}" \
  --worker-memory "${WORKER_MEMORY_GIB}" \
  --ssh-public-key-file "${SSH_PUBLIC_KEY_FILE}" \
  --csi-storage-container "${NUTANIX_STORAGE_CONTAINER}" \
  --csi-file-system "${CSI_FILESYSTEM}" \
  --csi-hypervisor-attached-volumes="${CSI_HYPERVISOR_ATTACHED}" \
  --kubernetes-service-load-balancer-ip-range "${LB_IP_RANGE}" \
  --kubernetes-pod-network-cidr="${POD_CIDR}" \
  --kubernetes-service-cidr="${SERVICE_CIDR}" \
  --registry-mirror-url "${REGISTRY_MIRROR_URL}" \
  --registry-mirror-username="${REGISTRY_USERNAME}" \
  --registry-mirror-password="${REGISTRY_PASSWORD}" \
  --registry-mirror-cacert "${REGISTRY_CACERT}" \
  --bootstrap-cluster-image "${BOOTSTRAP_IMAGE}" \
  --airgapped \
  --self-managed \
  "${SKIP_FLAG[@]}" \
  --wait
set +x

echo
echo "Done. kubeconfig: $CONFIG_DIR/${CLUSTER_NAME}.conf (or ~/${CLUSTER_NAME}.conf)"
echo "Next: point DNS ${CLUSTER_HOSTNAME} at the Traefik LB IP, then:"
echo "  export KUBECONFIG=\$HOME/${CLUSTER_NAME}.conf; nkp get dashboard"
