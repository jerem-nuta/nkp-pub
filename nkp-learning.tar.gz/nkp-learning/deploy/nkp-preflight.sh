#!/usr/bin/env bash
# NKP 2.17 air-gap pre-flight — run on the bastion AFTER sourcing nkp-deploy.env
#   set -a; source /mnt/nkp-sources/nkp-deploy.env; set +a
#   bash nkp-preflight.sh
# Checks files, certs, IPs, registry, PC reachability. Read-only — changes nothing.
ok(){ printf "  \033[32m✓\033[0m %s\n" "$1"; }
no(){ printf "  \033[31m✗\033[0m %s\n" "$1"; FAIL=1; }
wn(){ printf "  \033[33m!\033[0m %s\n" "$1"; }
FAIL=0

echo "── files & bundles ──"
for v in NKP_CLI_BUNDLE KONVOY_IMAGE_BUNDLE KOMMANDER_IMAGE_BUNDLE BOOTSTRAP_IMAGE; do
  f="${!v}"
  if [ -z "$f" ]; then wn "$v unset"; elif [ -f "$f" ]; then ok "$v -> $(basename "$f")"; else no "$v MISSING: $f"; fi
done

echo "── certs ──"
for v in REGISTRY_CACERT PC_CA_CERT INGRESS_CA INGRESS_CERT INGRESS_KEY; do
  f="${!v}"
  if [ -z "$f" ]; then wn "$v unset"; elif [ -f "$f" ]; then ok "$v present"; else no "$v MISSING: $f"; fi
done
# ingress cert SAN should cover CLUSTER_HOSTNAME
if [ -f "$INGRESS_CERT" ] && [ -n "$CLUSTER_HOSTNAME" ]; then
  if openssl x509 -in "$INGRESS_CERT" -noout -ext subjectAltName 2>/dev/null | grep -q "$CLUSTER_HOSTNAME"; then
    ok "ingress cert SAN includes $CLUSTER_HOSTNAME"
  else
    no "ingress cert SAN does NOT include $CLUSTER_HOSTNAME — dashboard TLS will mismatch"
    echo "      SAN: $(openssl x509 -in "$INGRESS_CERT" -noout -ext subjectAltName 2>/dev/null | tail -1 | tr -s ' ')"
  fi
fi
# ingress cert/key must pair
if [ -f "$INGRESS_CERT" ] && [ -f "$INGRESS_KEY" ]; then
  cm=$(openssl x509 -noout -modulus -in "$INGRESS_CERT" 2>/dev/null | openssl md5)
  km=$(openssl rsa  -noout -modulus -in "$INGRESS_KEY"  2>/dev/null | openssl md5)
  [ "$cm" = "$km" ] && ok "ingress cert+key modulus match" || no "ingress cert/key MISMATCH"
fi

echo "── addressing ──"
ipok(){ [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] && ! awk -F. '{for(i=1;i<=4;i++)if($i>255)exit 1}' <<<"$1"; }
ipok "$CONTROL_PLANE_ENDPOINT_IP" && ok "CP endpoint $CONTROL_PLANE_ENDPOINT_IP valid" || no "CP endpoint invalid: $CONTROL_PLANE_ENDPOINT_IP"
lo="${LB_IP_RANGE%-*}"; hi="${LB_IP_RANGE#*-}"
ipok "$lo" && ipok "$hi" && ok "LB range $LB_IP_RANGE valid" || no "LB range invalid: $LB_IP_RANGE"
# CP endpoint should be free (no ping reply)
if ping -c1 -W1 "$CONTROL_PLANE_ENDPOINT_IP" >/dev/null 2>&1; then
  no "CP endpoint $CONTROL_PLANE_ENDPOINT_IP ANSWERS ping — it must be UNUSED"
else ok "CP endpoint $CONTROL_PLANE_ENDPOINT_IP is free (no ping)"; fi
# CP endpoint must not fall inside the LB range
ip2n(){ IFS=.; set -- $1; echo $(( ($1<<24)+($2<<16)+($3<<8)+$4 )); }
cn=$(ip2n "$CONTROL_PLANE_ENDPOINT_IP"); ln=$(ip2n "$lo"); hn=$(ip2n "$hi")
if [ "$cn" -ge "$ln" ] && [ "$cn" -le "$hn" ]; then no "CP endpoint is INSIDE the LB range — must be separate"; else ok "CP endpoint outside LB range"; fi

echo "── name resolution ──"
for h in "$REGISTRY_HOST" "$NUTANIX_ENDPOINT" "$CLUSTER_HOSTNAME"; do
  [ -z "$h" ] && continue
  if getent hosts "$h" >/dev/null 2>&1; then ok "$h resolves -> $(getent hosts "$h" | awk '{print $1}' | head -1)"; else wn "$h does NOT resolve (add to DNS or /etc/hosts)"; fi
done

echo "── registry reachability + project ──"
if curl -fsS --cacert "$REGISTRY_CACERT" -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" \
   "$REGISTRY_URL/api/v2.0/health" >/dev/null 2>&1; then
  ok "Harbor health OK (TLS verified with REGISTRY_CACERT)"
else
  wn "Harbor health check failed with --cacert (CA trust or reachability?) — trying insecure"
  curl -fsSk -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" "$REGISTRY_URL/api/v2.0/health" >/dev/null 2>&1 \
    && wn "reachable but TLS NOT verified — bastion doesn't trust the registry CA yet" \
    || no "Harbor not reachable at $REGISTRY_URL"
fi
# does the mirror project exist?
if curl -fsSk -u "$REGISTRY_USERNAME:$REGISTRY_PASSWORD" \
   "$REGISTRY_URL/api/v2.0/projects?name=$REGISTRY_MIRROR_PROJECT" 2>/dev/null | grep -q "\"name\":\"$REGISTRY_MIRROR_PROJECT\""; then
  ok "mirror project '$REGISTRY_MIRROR_PROJECT' exists"
else
  wn "mirror project '$REGISTRY_MIRROR_PROJECT' not found yet (created by first push)"
fi

echo "── prism central reachability ──"
if curl -fsS --cacert "$PC_CA_CERT" "https://$NUTANIX_ENDPOINT:$NUTANIX_PORT/api/nutanix/v3/version" >/dev/null 2>&1 \
   || curl -fsSk "https://$NUTANIX_ENDPOINT:$NUTANIX_PORT" >/dev/null 2>&1; then
  ok "PC reachable at $NUTANIX_ENDPOINT:$NUTANIX_PORT"
else no "PC NOT reachable at $NUTANIX_ENDPOINT:$NUTANIX_PORT"; fi

echo "── bastion overlay MTU (Flow VPC needs 1442) ──"
mtu=$(ip link show docker0 2>/dev/null | grep -o 'mtu [0-9]*' | awk '{print $2}')
if [ -z "$mtu" ]; then wn "docker0 not present yet (docker not started / no bootstrap)"; 
elif [ "$mtu" = "1442" ]; then ok "docker0 MTU 1442"; 
else no "docker0 MTU is $mtu — set 1442 for Flow VPC overlay (kind/Docker will hang otherwise)"; fi

echo
[ "$FAIL" = 1 ] && { echo -e "\033[31mPRE-FLIGHT FAILED — fix the ✗ items above before deploying.\033[0m"; exit 1; } \
                || echo -e "\033[32mPRE-FLIGHT PASSED — safe to proceed.\033[0m"
