# nkp-learning — lab NKP mono-utilisateur, tout local

Version simplifiée : **Harbor (registre) + sources NKP (file server) + downloader**.
Un seul compte local, cert auto-signé généré au boot.
Pas d'Active Directory, pas de PKI d'entreprise, pas de portail.

Le **nom et l'IP de la VM viennent de Prism** : rien n'est codé en dur.
Les URL affichées utilisent l'**IP** (pas de dépendance DNS) ; le nom DNS reste
dans le SAN du certificat si la résolution fonctionne chez toi.

## Déploiement
1. Remplir `cloud-init-nkp-learning.yml` :
   - `REPLACE_WITH_PASSWORD` — 8+ caractères, 1 majuscule, 1 minuscule, 1 chiffre
     (contrainte Harbor). Ce mot de passe sert **partout**.
   - `REPLACE_WITH_YOUR_SSH_PUBKEY`
2. Coller dans Prism, nommer la VM, booter.
3. Suivre : `journalctl -u harbor-install -f`

Le bundle est cloné au boot depuis le repo public défini dans `BUNDLE_GIT`
(`/etc/nkp-learning.env`). Rien à copier à la main.

## Accès (cert auto-signé — à accepter dans le navigateur)
| Service | URL |
|---|---|
| Registre Harbor | `https://<IP>/` |
| Sources NKP | `https://<IP>:8080/` |
| Downloader | `https://<IP>:8080/downloader/` |

Identifiants : `admin` / le mot de passe du cloud-init.

```bash
docker login <IP> -u admin
```

## Déposer un bundle NKP
Placer les dossiers `nkp-x.y.z/` dans `/data/nkp-sources/` : ils apparaissent
dans le listing `:8080/`.

## Contenu
- `registry/` — bootstrap, installeur, conf nginx
- `registry-web/downloader-backend/` — le service de téléchargement
- `deploy/` — exemples de configuration cluster NKP (placeholders `<VM_IP>`, `<DOMAIN>`… à adapter)
